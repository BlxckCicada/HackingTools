<?php
$plugin->version = 2020061700;
$plugin->component = 'block_exploit';
